# Aurora Engineering Website

Open index.html in your browser.

Structure:
- index.html
- assets/css/style.css
- assets/js/main.js
- assets/img/logo.svg
